﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Interop;
using System.Runtime.InteropServices;
using Microsoft.Web.WebView2.Core;

namespace Bloxstrap.UI.Elements.Overlay
{
    public partial class OverlayWindow : Window
    {
        // Win32 API
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TOOLWINDOW = 0x00000080;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_NOACTIVATE = 0x08000000;

        [DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

        [DllImport("user32.dll")]
        private static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [DllImport("user32.dll")]
        private static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        private const int HOTKEY_ID = 9000;
        private const uint VK_F = 0x46;           // Клавиша F
        private const uint MOD_CONTROL = 0x0002;  // Модификатор Ctrl

        private bool _isVisible = true;

        public OverlayWindow()
        {
            InitializeComponent();
            SourceInitialized += OverlayWindow_SourceInitialized;
            Closed += OverlayWindow_Closed;
        }

        private void OverlayWindow_SourceInitialized(object sender, EventArgs e)
        {
            try
            {
                var hwnd = new WindowInteropHelper(this).Handle;
                int exStyle = GetWindowLong(hwnd, GWL_EXSTYLE);

                // WS_EX_NOACTIVATE - окно не активируется при клике
                // WS_EX_TOOLWINDOW - не появляется в Alt+Tab
                // WS_EX_LAYERED - поддерживает прозрачность
                SetWindowLong(hwnd, GWL_EXSTYLE, exStyle | WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE);

                // Регистрируем глобальную горячую клавишу F12
                RegisterHotKey(hwnd, HOTKEY_ID, MOD_CONTROL, VK_F);

                App.Logger.WriteLine("OverlayWindow", "Window initialized with NOACTIVATE flag and F12 hotkey registered");
            }
            catch (Exception ex)
            {
                App.Logger.WriteException("OverlayWindow::SourceInitialized", ex);
            }
        }

        private void OverlayWindow_Closed(object sender, EventArgs e)
        {
            try
            {
                var hwnd = new WindowInteropHelper(this).Handle;
                UnregisterHotKey(hwnd, HOTKEY_ID);
            }
            catch { }
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var source = PresentationSource.FromVisual(this) as HwndSource;
            source?.AddHook(WndProc);
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WM_HOTKEY = 0x0312;

            if (msg == WM_HOTKEY && wParam.ToInt32() == HOTKEY_ID)
            {
                ToggleVisibility();
                handled = true;
            }

            return IntPtr.Zero;
        }

        private void ToggleVisibility()
        {
            _isVisible = !_isVisible;
            this.Visibility = _isVisible ? Visibility.Visible : Visibility.Hidden;
            App.Logger.WriteLine("OverlayWindow", $"Overlay visibility toggled: {_isVisible}");
        }

        private async void WebView_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                App.Logger.WriteLine("OverlayWindow", "WebView2 loading started...");

                await WebView.EnsureCoreWebView2Async(null);
                App.Logger.WriteLine("OverlayWindow", "WebView2 core initialized");

                string htmlPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "overlay.html");
                App.Logger.WriteLine("OverlayWindow", $"Looking for HTML at: {htmlPath}");

                if (File.Exists(htmlPath))
                {
                    string htmlContent = File.ReadAllText(htmlPath);
                    WebView.NavigateToString(htmlContent);
                    App.Logger.WriteLine("OverlayWindow", "HTML content loaded successfully");
                }
                else
                {
                    App.Logger.WriteLine("OverlayWindow", $"ERROR: HTML file not found at: {htmlPath}");
                    App.Logger.WriteLine("OverlayWindow", $"Base directory: {AppDomain.CurrentDomain.BaseDirectory}");

                    // Показываем ошибку прямо в WebView
                    WebView.NavigateToString(@"
                        <html><body style='background:rgba(255,0,0,0.3);color:white;font-family:Arial;padding:20px;'>
                        <h1>Winstrap Overlay Error</h1>
                        <p>HTML file not found. Check logs for details.</p>
                        </body></html>");
                }
            }
            catch (Exception ex)
            {
                App.Logger.WriteException("OverlayWindow::WebView_Loaded", ex);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            try
            {
                WebView.Dispose();
            }
            catch { }
        }
    }
}